
# Sample Transaction Data for Fraud Detection Testing

This directory contains sample CSV files to test the fraud detection application:

## Files:

1. **normal_transactions.csv** - 20 legitimate transactions
   - Normal business hours (9-19)
   - Reasonable amounts ($23-$234)
   - Common locations (US, CA, UK)

2. **mixed_transactions.csv** - 25 transactions with mixed fraud patterns
   - Contains both normal and suspicious transactions
   - High amounts at odd hours
   - Unusual locations (RU, CN, XX)
   - Very small amounts (potential card testing)

3. **high_fraud_transactions.csv** - 20 transactions with high fraud indicators
   - Very high amounts ($7K-$25K)
   - Odd hours (0-5, 22-23)
   - Suspicious locations (XX, YY, CN, RU)
   - Very small amounts (card testing patterns)

## CSV Format:
- `user_id`: Unique identifier for the user
- `amount`: Transaction amount in USD
- `time_hour`: Hour of transaction (0-23)
- `merchant_category`: Category code (1-5)
- `location`: Country/location code

## Usage:
1. Train the model first using the "Train Model" button
2. Upload any of these CSV files using the "Upload Data" feature
3. Review the fraud detection results and risk scores

## Expected Results:
- **normal_transactions.csv**: Low fraud detection rate (0-10%)
- **mixed_transactions.csv**: Medium fraud detection rate (30-50%)
- **high_fraud_transactions.csv**: High fraud detection rate (70-90%)
